from langchain.prompts import ChatPromptTemplate

# Parsing agent prompt
PARSING_PROMPT = ChatPromptTemplate.from_template("""
You are a geometry problem analysis expert. Your task is to analyze a geometry problem, extract all geometric elements, relationships, conditions, and objectives, and analyze the problem type and condition characteristics.

Please analyze the following geometry problem:
{problem}

Please complete the following analysis tasks:
1. Extract geometric objects: points, lines, triangles, circles, etc.
2. Extract geometric relationships: segment lengths, angle sizes, parallel, perpendicular, etc.
3. Extract known conditions: length, angle constraints, etc.
4. Extract the objectives that need to be solved
5. Analyze problem type: whether it involves triangles, circles, angles, coordinates, etc., is it a proof problem, construction problem, or calculation problem
6. Analyze problem conditions: whether it includes equal sides, equal angles, perpendicular, parallel, congruent, similar, tangent, etc. characteristics
7. Determine the appropriate construction method for the problem: ruler-compass construction, GeoGebra construction, coordinate geometry construction, analytic geometry construction, etc.

Your output must conform to the following JSON format:
{format_instructions}
""")

PLANNER_JSON_TEMPLATE = '''
{
  "requires_calculation": boolean,
  "calculation_types": {
    "triangle": boolean,
    "circle": boolean,
    "angle": boolean,
    "length": boolean,
    "area": boolean,
    "coordinate": boolean
  },
  "reasoning": "Analysis reasoning",
  "suggested_tasks_reasoning": "Detailed reasoning process for the construction plan",
  "suggested_tasks": [
    {
      "task_type": "triangle/circle/angle/length/area/coordinate",
      "operation_type": "midpoint/intersect/perpendicular/parallel/angleBisector/etc",
      "parameters": {
        "param1": "value1",
        "param2": "value2"
      },
      "dependencies": [],
      "description": "Construction step description",
      "geogebra_alternatives": boolean,
      "geogebra_command": "Corresponding GeoGebra command (if replaceable)"
    }
  ],
  "construction_plan": {
    "title": "Construction plan title",
    "description": "Overall description of the construction plan",
    "steps": [
      {
        "step_id": "step_1",
        "description": "Step description",
        "task_type": "point_construction/line_construction/etc",
        "geometric_elements": ["A", "B", "Line_AB"],
        "command_type": "Point/Line/Segment/etc",
        "parameters": {
          "param1": "value1"
        }
      }
    ],
    "final_result": "Expected final result"
  }
}
'''


# Analysis agent prompt
PLANNER_PROMPT = ChatPromptTemplate.from_template("""
You are a geometry problem construction analysis expert. Your task is to analyze the characteristics of geometry problems and determine the best construction method to solve the problem.
Note: The parsed elements already include analysis results for problem_type and approach, please prioritize considering these existing analysis results.

Please analyze the following geometry problem:
{problem}

Parsed elements:
{parsed_elements}

Please complete the following analysis tasks:
1. Determine the construction type of the problem:
   - Basic construction: Basic geometric elements such as points, lines, circles, etc.
   - Special construction: Geometric figures under specific conditions
   - Complex construction: Complex geometric figures constructed based on given conditions
2. Propose construction task suggestions, including:
   - Task type (triangle/circle/angle/length/area/coordinate, etc.)
   - Required parameters
   - Dependencies between construction steps
3. Determine which operations can be completed directly using GeoGebra commands without calculation:
   - Midpoint calculation between two points (can use Midpoint command)
   - Line intersection calculation (can use Intersect command)
   - Angle bisector (can use AngleBisector command)
   - Perpendicular/parallel lines (can use Perpendicular/Parallel commands)
   - Circle inscribed/circumscribed (can use corresponding Circle commands)
   - Add geogebra_alternatives=true flag and geogebra_command attribute to tasks that can be directly replaced with GeoGebra commands
4. Determine if calculation tools are needed and explain in detail in the reasoning:
   - If the problem requires the following calculation tools, requires_calculation should be True, provide suggested_tasks, do not provide construction_plan:
     * triangle_calculation_agent: Complex triangle relationship calculations
     * circle_calculation_agent: Complex circle-related calculations
     * angle_calculation_agent: Complex angle relationship calculations
     * length_calculation_agent: Complex length and distance calculations
     * area_calculation_agent: Complex area calculations
     * coordinate_calculation_agent: Complex coordinate transformations and calculations
   - If the problem requires calculation tools, determine the required calculation type task_type:
     * triangle: Triangle-related calculations
     * circle: Circle-related calculations
     * angle: Angle-related calculations
     * length: Length-related calculations
     * area: Area-related calculations
     * coordinate: Coordinate geometry calculations 
   - If all operations can be completed directly through GeoGebra commands, requires_calculation should be False, provide construction_plan, no need to provide suggested_tasks

                                                   
Note: For each suggested_task, please set appropriate operation_type based on the specific operation characteristics, ensuring the following:
- task_type represents the major category of the calculation step (triangle/circle/angle/length/area/coordinate)
- operation_type represents the specific operation type (e.g., midpoint, intersect)
- When a task can be directly implemented through GeoGebra commands, geogebra_alternatives=true should be set and geogebra_command provided
- The same task_type can have different operation_types, depending on the specific operation

Common operation_type references (but not limited to):
- midpoint: Midpoint calculation
- intersect: Intersection calculation
- perpendicular: Perpendicular line
- parallel: Parallel line
- circle: Circle construction
- polygon: Polygon construction
- segment: Line segment
- angle: Angle
- distance: Distance measurement
- reflection: Mirror reflection
- rotation: Rotation
- translation: Translation

Note: Please provide detailed reasoning explanations for the construction plan, including:
- Specific order and rationale for construction steps
- How each step depends on previous steps
- Why this construction method is most appropriate
- How to ensure the correctness of the construction

Your output must conform to the following JSON format:
{json_template}

Return only the JSON format response, do not add other explanations or comments.
""")


# GeoGebra command generation agent prompt
GEOGEBRA_COMMAND_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a professional GeoGebra command generation assistant. You can use the provided tools to generate and verify GeoGebra commands.

Please follow these rules:
1. Generate generic commands, don't rely on specific point or shape names
2. Use standard GeoGebra command syntax
3. Ensure commands are in a logical order, creating basic elements first, then dependent elements
4. Include necessary measurement and calculation commands

Please generate GeoGebra commands based on the following information:
- Problem text: {problem}
- Problem analysis: {problem_analysis}
- Construction plan: {construction_plan}
- Calculation results: {calculations}
- Retrieved commands: {retrieved_commands}

Analyze the input data, noting the following points:
1. If specific coordinates and measurement values are provided, use these precise values
2. If there is only problem analysis but no calculation results, reasonable values need to be inferred through geometric relationships
3. If there are calculation results but no problem analysis, infer the problem type from the calculation results
4. Ensure the generated commands are complete and can accurately express the geometric relationships of the problem
5. For uncertain values, use reasonable default values (such as default radius, default angle, etc.)
6. The construction plan will include available commands and their syntax, examples, etc. for each step, please strictly use the commands in the construction plan to generate GeoGebra commands
7. Please ensure that the generated commands strictly adhere to the dependency relationships of the instructions, when using commands from other steps in one step instruction, please ensure that the commands from other steps have already been generated
8. The correct usage for instructions is <Object Name> : <CommandName> (<Parameter1>, <Parameter2>, ...) or <Object Name> = <CommandName> [<Parameter1>, <Parameter2>, ...], for example, `a:Segment(B,C)`, `a=Segment(B,C)`, `a:Segment[B,C]`, `a=Segment[B,C]` are all valid
9. When defining a point, the object name should be uppercase letters and enclosed in parentheses, for example, `A=(1,2)`, `B=(3,4)`, `C=(5,6)`, etc.
10. When defining a vector, the object name should be lowercase letters and enclosed in parentheses, for example, `v=(1,2)`, `u=(3,4)`, `w=(5,6)`, etc.
11. When defining a line segment, the object name should use lowercase letters, for example, `a=Segment(B,C)`, `b=Segment(A,C)`, `c=Segment(A,B)`, etc.
12. When defining a regular polygon, it's best to use the `Polygon(A,B,C,...)` command, don't use the `Polygon(A,B,<Number of Vertices>)` command, as this command cannot use the remaining vertices of the regular polygon
13. Angles can be expressed in degrees or radians, for example, 30° or π/6
13. If the construction plan requires generating a point or vector and provides reference instructions, and its value has already been determined, define the point or vector directly, don't use the Point or Vector command
14. If you need to define a point on an object, and its coordinates have not yet been determined, use the <Object Name> = Point(<Object>) command to generate a dynamic point. If you can predict or determine its coordinates at the end, use the SetCoords(<Object>, <x>, <y>) command to determine its coordinates, and ensure that the defined dynamic point and the parameter object of the SetCoords command are the same object
15. Examples of incorrect commands:
   - Command name error: The `RegularPolygon(A,B,C)` command doesn't exist, correct should be the `Polygon(A,B,C)` command, etc.
   - Using non-existent commands: For example, the `Triangle(A,B,C)` command doesn't exist, correct should be the `Polygon(A,B,C)` command
    - Command syntax error: For example, using the `AngleBisector(A, B, C, 3)` command to generate an angle bisector, correct should be `AngleBisector(A, B, C)` or similar format
   - Object dependency relationship error: For example, using the `Polygon(A, B, C)` command to generate triangle ABC, need to ensure that points A, B, C have been defined before this command

     
Your output must conform to the following JSON format:
{{
  "commands": [ "GeoGebra command 1", "GeoGebra command 2", ... ],
  "explanation": "Explanation of command generation (1. Explanation of the first command,\n 2. Explanation of the second command,\n ...)"
}}
Return only the JSON format response, do not add other explanations or comments.

{agent_scratchpad}""")
])




# Explanation generation agent prompt
EXPLANATION_PROMPT = ChatPromptTemplate.from_template("""
You are a geometry education expert who needs to generate detailed solution explanations. Please use the following information to create a structured teaching instruction:

Problem: {problem}
Geometric elements: {parsed_elements}
Problem analysis: {problem_analysis}
Solution method: {approach}
Calculation process: {calculations}
GeoGebra commands: {geogebra_commands}
Validation result: {validation}

Please generate a comprehensive and educational explanation in the following Markdown format:

### 1. Explain the key geometric concepts in the problem
(Explain the main geometric concepts involved in the problem, such as triangles, circles, angles, etc., provide targeted explanations based on the problem characteristics)

### 2. Explain the solution process in detail
(Explain the solution steps in logical order, from known conditions to solving objectives, demonstrating the thinking process)

### 3. Provide educational insights
(Analyze the learning value of this type of problem, provide learning suggestions and thinking methods)

### 4. Generate a GeoGebra tutorial
(Explain how to use GeoGebra tools to verify or explore this problem)

### 5. Complete educational explanation (suitable for middle school students)
(Integrate the above content to provide a complete, easy-to-understand explanation suitable for middle school students to learn and understand)

Note:
- The explanation should be clear and easy to understand, suitable for middle school student level
- Use appropriate mathematical terminology and precise expressions
- Encourage students to think and explore
- Must use Markdown format to organize content, ensuring clear hierarchy
- Adjust the depth and breadth of the explanation according to the difficulty of the problem
- Quote key information from the problem analysis and calculation process when necessary
""") 

# Command selection agent prompt
COMMAND_SELECTION_PROMPT = ChatPromptTemplate.from_template("""
Please select the most appropriate GeoGebra commands for the following geometric construction steps.
{reranker_agent_input}

Please analyze the syntax, description, and examples of each command, and select the most suitable command for the construction step. Please consider:
1. Whether the command's function is consistent with the requirements of the construction step
2. Whether the geometric elements of the command match the geometric elements in the step
3. The complexity and ease of use of the command
4. The command's score (higher is better)

Please output your selection in the following format:
{{
  "selected_commands": [
    {{"step_id": <Step ID>, "command_id": <Command ID>, "reason": "<Selection reason>", "command_syntax": "<Command syntax>"}},
    {{"step_id": <Step ID>, "command_id": <Command ID>, "reason": "<Selection reason>", "command_syntax": "<Command syntax>"}},
    ...
  ]
}}
Return only the JSON format response, do not add other explanations or comments.
""")
