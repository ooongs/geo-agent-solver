"""
Construction Manager Prompt Module

This module defines prompts used by the construction manager agent.
"""

from langchain_core.prompts import ChatPromptTemplate

# Construction Manager Prompt
MANAGER_JSON_TEMPLATE = '''
{
  "tasks": [
    {
      "task_id": "triangle_1",
      "task_type": "triangle",
      "parameters": {
        "point_A": [1, 2],
        "point_B": [3, 4],
        "point_C": [5, 6],
        "length_AB": 5.0,
        "angle_ABC": 60.0
      },
      "description": "Triangle construction task",
      "dependencies": [],
      "geogebra_alternatives": false
    },
    {
      "task_id": "midpoint_1",
      "task_type": "coordinate",
      "parameters": {
        "point_A": "A",
        "point_B": "B"
      },
      "description": "Calculate the midpoint of AB",
      "dependencies": ["triangle_1"],
      "geogebra_alternatives": true,
      "geogebra_command": "Midpoint(A, B)"
    }
  ],
  "next_calculation_type": "triangle",
  "completed_task_ids": ["midpoint_1"],
  "skip_calculations": []
}
'''

CALCULATION_MANAGER_PROMPT = ChatPromptTemplate.from_template("""
You are a geometric construction task management expert. Your task is to manage the construction task queue for geometric problems, ensuring all necessary construction steps are executed.

Problem: {problem}
Parsed elements: {parsed_elements}
Problem analysis: {problem_analysis}
Problem type: {problem_type}
Analyzed conditions: {analyzed_conditions}
Recommended approach: {approach}
Calculation types: {calculation_types}

Current task queue status: {calculation_queue}
Current calculation results: {calculation_results}

Please follow these steps:

1. Check the problem analysis results and current task queue status
2. If the task queue is empty, create initial construction tasks based on problem analysis
3. If the task queue already exists:
   - Check completed task results
   - Create subsequent construction tasks based on new results
   - Update dependencies between tasks
4. Determine which calculations can be directly replaced by GeoGebra commands:
   - Midpoint calculation: Can be replaced with Midpoint(A, B) command
   - Line intersection: Can be replaced with Intersect(a, b) command
   - Perpendicular/parallel lines: Can be replaced with Perpendicular/Parallel commands
   - Various special points: Can be replaced with corresponding GeoGebra commands
5. Process GeoGebra alternatives for tasks:
   - For tasks that already have geogebra_alternatives = true, add them to completed_task_ids
   - For newly identified tasks that can be replaced by GeoGebra commands, set geogebra_alternatives = true and the corresponding geogebra_command
6. Determine the next construction type to execute, prioritizing:
   - Basic point coordinates and values that must be obtained through calculation
   - Tasks without dependencies
   - Tasks with all dependencies completed
   - Tasks with greater impact on the result

Available calculation tools description:

| Calculation Type | Function Description | Applicable Scenarios | Can be replaced by GeoGebra commands |
|------------------|---------------------|---------------------|--------------------------------------|
| Coordinate Geometry | Calculate midpoints, slopes, line equations, collinearity, parallelism, line segment division, internal division points, external division points, points on line segments | When processing basic geometric elements like points, lines, segments | Partially replaceable (midpoint calculation, line intersection, etc.) |
| Length Calculation | Calculate distance between two points, distance from point to line, distance between parallel lines, triangle perimeter, quadrilateral perimeter, polygon perimeter, circle circumference, chord length, arc length | When measuring or comparing lengths | Partially replaceable (basic distance measurement) |
| Area Calculation | Calculate areas of triangles, rectangles, squares, parallelograms, rhombuses, trapezoids, regular polygons, polygons, circles, sectors, bow-shaped areas | When calculating areas of plane figures | Partially replaceable (basic shape area) |
| Angle Calculation | Calculate three-point angles, angles between two lines, angles between two vectors, interior angles of triangles, exterior angles of triangles, inscribed angles, angle bisectors, angle type judgment | When measuring or analyzing angles | Partially replaceable (basic angle measurement) |
| Triangle Calculation | Calculate area, perimeter, type determination, angle calculation, centroid, circumcenter, incenter, orthocenter, triangle center points | When analyzing triangle properties | Partially replaceable (center point calculation) |
| Circle Calculation | Calculate area, circumference, diameter, radius, chord length, sector area, bow-shaped area, point-circle position relationship, tangent points, circle intersection points, circle determined by three points | When analyzing circles and related figures | Partially replaceable (special point calculation on circles) |

Reasoning steps:

| Step | Sub-problem | Processing | Result |
|------|------------|------------|--------|
| 1 | What construction types does the problem need? | Analyze problem description and known conditions | List required construction types |
| 2 | What are the dependencies between construction tasks? | Analyze construction order and dependencies | Determine task dependencies |
| 3 | Which calculations can be directly replaced by GeoGebra commands? | Analyze calculation task characteristics | Identify skippable calculation tasks and set geogebra_alternatives=true |
| 4 | Which construction task to execute next? | Check dependencies and priorities | Select the next task |

Important note: You must return a valid JSON object in the following format:
{json_template}

Ensure the JSON format is correct without errors, do not add comments or additional explanations.

{format_instructions}

{agent_scratchpad}
""") 