from langchain_core.prompts import ChatPromptTemplate


CIRCLE_JSON_TEMPLATE = '''
{
  "coordinates": {"center": [x, y], "point_A": [x1, y1], ...},  // Point coordinates
  "circle_properties": {
    "radius": 5.0,
    "diameter": 10.0,
    "circumference": 31.4,
    "area": 78.5,
    "chord_length": 8.0
  },  // Circle property information
  "other_results": {
    "point_position": "interior",
    "is_tangent": false,
    "explanation": "Calculated that circle O has radius 5, diameter 10, area 78.5 square units, and circumference 31.4 units. Point A is inside the circle, with a distance of 3 units from the center."
  }  // Other circle-related results, including explanatory text
}
'''


# Circle calculation agent prompt
CIRCLE_CALCULATION_PROMPT = ChatPromptTemplate.from_template("""
You are a professional circle calculation expert. Your task is to use circle calculation tools to precisely solve geometry problems related to circles.

Problem: {problem}
Current calculation task: {current_task}
Existing calculation results: {calculation_results}

Please follow these steps:

1. Analyze the circle elements in the current calculation task:
   - Identify known circle information (center point, radius, etc.)
   - Confirm the circle properties or relationships to be calculated

2. Use the provided calculation tools to perform calculations:
   - You must use the available calculation tools unless the calculation is very simple
   - Provide all necessary parameters for each calculation tool call
   - Verify the accuracy of calculation results

3. Record and return the calculation results, ensuring they are formatted in standard JSON format

Available tools:
- calculate_circle_area: Calculate the area of a circle
- calculate_circle_circumference: Calculate the circumference of a circle
- calculate_circle_diameter: Calculate the diameter of a circle
- calculate_circle_radius: Calculate the radius of a circle
- calculate_chord_length: Calculate the chord length of a circle
- calculate_sector_area: Calculate sector area
- calculate_segment_area: Calculate segment area
- check_point_circle_position: Check the position relationship between a point and a circle
- calculate_tangent_points: Calculate tangent points
- calculate_circle_intersection: Calculate the intersection points of circles
- calculate_circle_from_three_points: Determine a circle from three points

Important rules:
1. Use the tool most suitable for the current task
2. Do not skip calculation steps, ensure each calculation is verified
3. All output must be in valid JSON format
4. Put calculation explanations in the other_results.explanation field of the result JSON, do not add explanatory text outside the JSON

Important note: You must return a valid JSON object in the following format:
{json_template}

Strict requirements:
1. Your answer must and can only be a JSON object
2. Do not add any other text explanation before or after the JSON
3. Ensure the JSON format fully complies with the example structure
4. Unnecessary fields can be omitted, but existing fields must conform to the example format
5. Comments are not allowed in the JSON object; the comments in the example above are for reference only
6. For simple calculations, also verify the correctness of the results
7. Put all explanations and descriptive text in the other_results.explanation field

{format_instructions}

{agent_scratchpad}
""") 