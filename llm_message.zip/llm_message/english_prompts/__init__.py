"""
Calculation Manager Prompts Package

This package provides prompts used by the calculation manager agent.
"""

from llm_message.english_prompts.manager_prompt import CALCULATION_MANAGER_PROMPT
from llm_message.english_prompts.area_prompt import AREA_CALCULATION_PROMPT
from llm_message.english_prompts.angle_prompt import ANGLE_CALCULATION_PROMPT
from llm_message.english_prompts.coordinate_prompt import COORDINATE_CALCULATION_PROMPT
from llm_message.english_prompts.length_prompt import LENGTH_CALCULATION_PROMPT
from llm_message.english_prompts.triangle_prompt import TRIANGLE_CALCULATION_PROMPT
from llm_message.english_prompts.manager_prompt import MANAGER_JSON_TEMPLATE
from llm_message.english_prompts.area_prompt import AREA_JSON_TEMPLATE
from llm_message.english_prompts.angle_prompt import ANGLE_JSON_TEMPLATE
from llm_message.english_prompts.coordinate_prompt import COORDINATE_JSON_TEMPLATE
from llm_message.english_prompts.length_prompt import LENGTH_JSON_TEMPLATE
from llm_message.english_prompts.triangle_prompt import TRIANGLE_JSON_TEMPLATE

__all__ = [
    "CALCULATION_MANAGER_PROMPT", 
    "AREA_CALCULATION_PROMPT", 
    "ANGLE_CALCULATION_PROMPT", 
    "COORDINATE_CALCULATION_PROMPT", 
    "LENGTH_CALCULATION_PROMPT", 
    "TRIANGLE_CALCULATION_PROMPT",
    "MANAGER_JSON_TEMPLATE",
    "AREA_JSON_TEMPLATE",
    "ANGLE_JSON_TEMPLATE",
    "COORDINATE_JSON_TEMPLATE",
    "LENGTH_JSON_TEMPLATE",
    "TRIANGLE_JSON_TEMPLATE"
] 