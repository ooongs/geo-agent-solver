"""
Result Merger Agent Prompt Module

This module defines prompts used by the result merger agent.
"""

from langchain_core.prompts import ChatPromptTemplate


MERGER_JSON_TEMPLATE = '''
{
  "coordinates": {"A": [x1, y1], "B": [x2, y2], ...},
  "lengths": {"AB": 5.0, "BC": 7.0, ...},
  "angles": {"ABC": 60.0, "BCD": 45.0, ...},
  "areas": {"triangle_ABC": 25.0, ...},
  "perimeters": {"triangle_ABC": 20.0, ...},
  "special_points": {"centroid": [x, y], "orthocenter": [x, y], ...},
  "circle_properties": {"radius": 5.0, "center": [x, y], ...},
  "ratios": {"AB:BC": 2.5, ...},
  "other_results": {
    "final_answer": "The area of triangle ABC is 25 square units",
    "explanation": "By calculating the sides and angles of triangle ABC, we determined that it is a 3-4-5 right triangle with an area of 25 square units"
  },
  "construction_plan": {
    "title": "Construction plan title",
    "description": "Overall description of the construction plan",
    "steps": [
      {
        "step_id": "step_1",
        "description": "Step description",
        "task_type": "point_construction/line_construction/etc",
        "geometric_elements": ["A", "B", "Line_AB"],
        "command_type": "Point/Line/Segment/etc",
        "parameters": {
          "param1": "value1"
        },
        "geogebra_command": "Optional direct GeoGebra command"
      }
    ],
    "final_result": "Expected final result"
  }
}
'''

# Result merger agent prompt
RESULT_MERGER_PROMPT = ChatPromptTemplate.from_template("""
You are a professional geometry calculation result integration and construction plan expert. Your task is to analyze and integrate all calculation results, ensure their consistency and accuracy, and create a detailed geometric construction plan.

Problem: {problem}
Completed calculation tasks: {completed_tasks}
Current calculation results: {calculation_results}
Problem analysis: {problem_analysis}

Please follow these steps:

1. Analyze all completed calculation tasks and existing results:
   - Check the consistency of calculation results
   - Identify possible contradictions or errors
   - Confirm whether all calculations meet the problem requirements

2. Integrate all calculation results:
   - Merge results of the same type
   - Ensure consistency of final results
   - Perform unit conversions and standardization when necessary
   - Provide an explanation of the integration process in the other_results.explanation field

3. Create a detailed geometric construction plan:
   - Design clear construction steps based on calculation results and problem requirements
   - Each step should include specific operation descriptions and required geometric elements
   - Ensure logical order between steps is reasonable
   - Clearly specify the expected final result

4. Generate final results:
   - Provide the final answer to the problem in the other_results.final_answer field
   - Ensure the result is clear, accurate, and complete
   - Return all results and the construction plan in standard JSON format

Important rules:
1. Ensure all results maintain consistency, especially units and naming
2. The construction plan must be clear and complete, able to guide users step by step through the geometric construction
3. Construction steps must match calculation results, ensuring mathematical accuracy
4. All output must be in valid JSON format

The returned JSON must include a construction_plan object containing:
- title: Construction plan title
- description: Overall description of the construction plan
- steps: Array of construction steps, each containing id, description, geometric elements, etc.
- final_result: Description of the expected final result

Important note: You must return a valid JSON object in the following format:
{json_template}

Strict requirements:
1. Your answer must and can only be a JSON object
2. Do not add any other text explanation before or after the JSON
3. Ensure the JSON format fully complies with the example structure
4. Unnecessary fields can be omitted, but existing fields must conform to the example format
5. Must include the construction_plan object and all its necessary fields
6. Integrate calculation results from all sources
7. Please provide the final answer, explanation, and construction plan in English

{agent_scratchpad}
""") 